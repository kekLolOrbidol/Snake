package com.snake.eat.finish.model.entity

data class Apple(val x: Int, val y: Int) {
    constructor(): this(-1, -1)
}